import json

class Book:
    def __init__(self, title: str, author: str, year: int, genre: str):
        self.title = title
        self.author = author
        self.year = year
        self.genre = genre

    def __str__(self):
        return f"{self.title} by {self.author} ({self.year}) - Genre: {self.genre}"

    def __eq__(self, other):
        return self.title == other.title and self.author == other.author


class Reader:
    def __init__(self, name: str, reader_id: int):
        self.name = name
        self.reader_id = reader_id
        self.borrowed_books = []

    def borrow_book(self, book: Book):
        if book not in self.borrowed_books:
            self.borrowed_books.append(book)
        else:
            raise Exception(f"{self.name} has already borrowed '{book.title}'.")

    def return_book(self, book: Book):
        if book in self.borrowed_books:
            self.borrowed_books.remove(book)
        else:
            raise Exception(f"{self.name} does not have '{book.title}' borrowed.")

    def __str__(self):
        return f"{self.name} (ID: {self.reader_id}) - Borrowed Books: {[book.title for book in self.borrowed_books]}"


class Library:
    def __init__(self, name: str):
        self.name = name
        self.books = []
        self.readers = []

    def add_book(self, book: Book):
        self.books.append(book)

    def remove_book(self, book: Book):
        try:
            self.books.remove(book)
        except ValueError:
            raise Exception(f"Book '{book.title}' not found in the library.")

    def register_reader(self, reader: Reader):
        self.readers.append(reader)

    def lend_book(self, reader: Reader, book: Book):
        if book in self.books:
            reader.borrow_book(book)
            self.remove_book(book)
        else:
            raise Exception(f"Book '{book.title}' is not available in the library.")

    def return_book(self, reader: Reader, book: Book):
        reader.return_book(book)
        self.add_book(book)

    def find_book(self, title: str = None, author: str = None):
        found_books = []
        for book in self.books:
            if (title and title.lower() in book.title.lower()) or \
                    (author and author.lower() in book.author.lower()):
                found_books.append(book)
        return found_books

    def get_reader_books(self, reader: Reader):
        return reader.borrowed_books

    def save_to_file(self, filename: str):
        data = {
            "books": [vars(book) for book in self.books],
            "readers": [vars(reader) for reader in self.readers],
        }
        with open(filename, 'w') as f:
            json.dump(data, f)

    def load_from_file(self, filename: str):
        with open(filename, 'r') as f:
            data = json.load(f)
            self.books = [Book(**book) for book in data["books"]]
            self.readers = [Reader(**reader) for reader in data["readers"]]


if __name__ == "__main__":
    library = Library("City Library")

    book1 = Book("1984", "George Orwell", 1949, "Dystopian")
    book2 = Book("To Kill a Mockingbird", "Harper Lee", 1960, "Fiction")
    library.add_book(book1)
    library.add_book(book2)

    reader1 = Reader("Alice", 1)
    library.register_reader(reader1)

    try:
        library.lend_book(reader1, book1)
        print(f"{reader1.name} borrowed: {book1.title}")
    except Exception as e:
        print(e)

    print(reader1)

    try:
        library.return_book(reader1, book1)
        print(f"{reader1.name} returned: {book1.title}")
    except Exception as e:
        print(e)

    library.save_to_file("library_data.json")

    new_library = Library("New Library")
    new_library.load_from_file("library_data.json")
    print("Books in the new library:")
    for book in new_library.books:
        print(book)
