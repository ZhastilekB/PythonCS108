import sys
import cv2
from PyQt5.QtWidgets import (QApplication, QWidget, QPushButton, QLabel, QVBoxLayout,
                             QFileDialog, QSlider, QHBoxLayout)
from PyQt5.QtCore import Qt, QTimer

class VideoPlayer(QWidget):
    def __init__(self):
        super().__init__()

        self.video_path = ''
        self.cap = None
        self.timer = QTimer()
        self.current_frame = 0
        self.is_playing = False

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Минималистичный Видеоплеер')

        self.label = QLabel('Выберите видеофайл', self)
        self.slider = QSlider(Qt.Horizontal, self)
        self.slider.setDisabled(True)

        self.play_button = QPushButton('Играть', self)
        self.play_button.clicked.connect(self.toggle_play)

        self.load_button = QPushButton('Выбрать файл', self)
        self.load_button.clicked.connect(self.load_file)

        layout = QVBoxLayout()
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.load_button)
        button_layout.addWidget(self.play_button)

        layout.addWidget(self.label)
        layout.addWidget(self.slider)
        layout.addLayout(button_layout)

        self.setLayout(layout)

        self.timer.timeout.connect(self.update_frame)

    def load_file(self):
        options = QFileDialog.Options()
        self.video_path, _ = QFileDialog.getOpenFileName(self, "Выберите видеофайл", "",
                                                         "Video Files (*.mp4 *.avi *.mov);;All Files (*)", options=options)
        if self.video_path:
            self.label.setText(self.video_path)
            self.cap = cv2.VideoCapture(self.video_path)
            self.slider.setMaximum(int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT)))
            self.slider.setValue(0)
            self.current_frame = 0
            self.slider.setDisabled(False)

    def toggle_play(self):
        if self.cap is None:
            return

        if not self.is_playing:
            self.timer.start(33)  # Примерно 30 FPS
            self.play_button.setText('Пауза')
            self.is_playing = True
        else:
            self.timer.stop()
            self.play_button.setText('Играть')
            self.is_playing = False

    def update_frame(self):
        if self.cap.isOpened() and self.current_frame < self.slider.maximum():
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, self.current_frame)
            ret, frame = self.cap.read()
            if ret:
                cv2.imshow('Video', frame)
                self.current_frame += 1
                self.slider.setValue(self.current_frame)
            else:
                self.timer.stop()
                self.play_button.setText('Играть')
                self.current_frame = 0
                self.slider.setValue(0)

    def closeEvent(self, event):
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    player = VideoPlayer()
    player.resize(400, 200)
    player.show()
    sys.exit(app.exec_())
