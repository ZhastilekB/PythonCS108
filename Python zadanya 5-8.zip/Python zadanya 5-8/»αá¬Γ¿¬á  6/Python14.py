import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QVBoxLayout

class SimpleApp(QWidget):
    def __init__(self):
        super().__init__()

        self.initUI()

    def initUI(self):
        self.setWindowTitle('Простое приложение')

        self.label = QLabel('Нажмите кнопку', self)
        self.label.setStyleSheet("font-size: 16px;")

        self.button = QPushButton('Нажми меня', self)
        self.button.setStyleSheet("background-color: lightblue; font-size: 14px;")

        self.button.clicked.connect(self.on_button_click)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.button)

        self.setLayout(layout)

    def on_button_click(self):
        self.label.setText('Кнопка нажата!')
        self.change_style()

    def change_style(self):
        self.label.setStyleSheet("font-size: 18px; color: red;")
        self.button.setStyleSheet("background-color: green; font-size: 14px;")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = SimpleApp()
    ex.resize(300, 200)
    ex.show()
    sys.exit(app.exec_())
