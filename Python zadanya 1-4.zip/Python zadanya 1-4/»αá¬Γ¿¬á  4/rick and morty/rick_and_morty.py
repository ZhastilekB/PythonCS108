import requests
from typing import List, Dict, Any

class RickAndMortyClient:
    BASE_URL = "https://rickandmortyapi.com/api"

    def get_random_character(self) -> Dict[str, Any]:
        response = requests.get(f"{self.BASE_URL}/character/random")
        return response.json()

    def search_characters(self, name: str) -> List[Dict[str, Any]]:
        response = requests.get(f"{self.BASE_URL}/character", params={"name": name})
        return response.json().get("results", [])

    def get_all_locations(self) -> List[Dict[str, Any]]:
        response = requests.get(f"{self.BASE_URL}/location")
        return response.json().get("results", [])

    def search_episodes(self, name: str) -> List[Dict[str, Any]]:
        response = requests.get(f"{self.BASE_URL}/episode", params={"name": name})
        return response.json().get("results", [])

    def analyze_character_status(self) -> Dict[str, int]:
        response = requests.get(f"{self.BASE_URL}/character")
        characters = response.json().get("results", [])
        status_count = {}

        for character in characters:
            status = character.get("status")
            if status in status_count:
                status_count[status] += 1
            else:
                status_count[status] = 1

        return status_count


if __name__ == "__main__":
    client = RickAndMortyClient()


    random_character = client.get_random_character()
    print(f"Случайный персонаж: {random_character['name']}")


    characters = client.search_characters("Rick")
    print("Персонажи с именем 'Rick':", [char['name'] for char in characters])


    locations = client.get_all_locations()
    print("Список всех локаций:", [loc['name'] for loc in locations])


    episodes = client.search_episodes("Pilot")
    print("Эпизоды с названием 'Pilot':", [ep['name'] for ep in episodes])

    status_analysis = client.analyze_character_status()
    print("Статус персонажей:", status_analysis)
