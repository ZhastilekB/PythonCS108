def write_and_read_file(filename, content):
    with open(filename, 'w') as file:
        file.write(content)

    with open(filename, 'r') as file:
        return file.read()


if __name__ == "__main__":
    filename = "example.txt"
    content = "Привет, мир!"

    file_content = write_and_read_file(filename, content)
    print("Содержимое файла:", file_content)
