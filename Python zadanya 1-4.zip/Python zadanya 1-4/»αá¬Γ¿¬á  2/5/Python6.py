def tuple_stats(tpl):
    total_sum = sum(tpl)

    average = total_sum / len(tpl) if tpl else 0
    unique_elements = tuple(set(tpl))

    return total_sum, average, unique_elements

def main():
    user_input = input("Введите числа через запятую (например, 1, 2, 3): ")

    try:
        tpl = tuple(map(float, user_input.split(',')))
    except ValueError:
        print("Ошибка: Пожалуйста, вводите только числа.")
        return


    total_sum, average, unique_elements = tuple_stats(tpl)
    print(f"Сумма: {total_sum}")
    print(f"Среднее значение: {average}")
    print(f"Уникальные элементы: {unique_elements}")

if __name__ == "__main__":
    main()
