def average_grade(Student):
    return sum(Student['grades']) / len(Student['grades'])
student = {
    'name': 'Bulat Zhastilek',
    'age': 19,
    'grades': [90, 100, 84, 88, 95]
}
average_student_grade = average_grade(student)
print("Средняя оценка студента:", average_student_grade)
