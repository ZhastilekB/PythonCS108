phone_book = {
    "454-454-7676": "Messi",
    "965-654-3210": "James",
    "576-343-4567": "Carl",
    "546-262-3333": "Mari"
}

def reverse_lookup(name):

    for phone, person in phone_book.items():
        if person == name:
            return phone
    return None
if __name__ == "__main__":
    name_to_lookup = input("Введите имя для поиска номера телефона: ")
    phone_number = reverse_lookup(name_to_lookup)

    if phone_number:
        print(f"Номер телефона для {name_to_lookup}: {phone_number}")
    else:
        print(f"Имя {name_to_lookup} не найдено в телефонной книге.")
